#!/usr/bin/env python3
"""
CodeClip - a context-aware clipboard history manager for developers.

Watches the clipboard, classifies each item (color, URL, code, JSON, path,
email, text), stores it in SQLite, and lets you search, filter, pin and
re-copy anything. No third-party dependencies (Python 3.8+ with tkinter).

Run:  python codeclip.py
"""
import json
import re
import sqlite3
import time
import tkinter as tk
from pathlib import Path
from tkinter import ttk

DB_PATH = Path.home() / ".codeclip.db"
POLL_MS = 500
MAX_LEN = 100_000

# ---------------------------------------------------------------- classify
HEX_RE = re.compile(r"^#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$")
RGB_RE = re.compile(r"^rgba?\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})\s*(?:,\s*[\d.]+\s*)?\)$", re.I)
URL_RE = re.compile(r"^(?:https?|ftp)://\S+$", re.I)
EMAIL_RE = re.compile(r"^[\w.+-]+@[\w-]+(?:\.[\w-]+)+$")
PATH_RE = re.compile(r"^(?:[A-Za-z]:[\\/]|/|~/|\./|\.\./)[^\n]*$")

LANG_HINTS = {
    "python": [r"^\s*def \w+\(", r"^\s*import \w+", r"^\s*from \w+ import", r"^\s*class \w+.*:\s*$", r"\bself\.", r"^\s*elif\b"],
    "javascript": [r"\bconst \w+ =", r"\blet \w+ =", r"=>", r"\bfunction\b", r"console\.log", r"\bawait\b"],
    "html": [r"</?\w+[^>]*>", r"<!DOCTYPE"],
    "css": [r"[.#]?[\w-]+\s*\{[^}]*:[^}]*;", r"^\s*[\w-]+\s*:\s*[^;]+;\s*$"],
    "sql": [r"\bSELECT\b.+\bFROM\b", r"\bINSERT INTO\b", r"\bUPDATE\b.+\bSET\b", r"\bCREATE TABLE\b"],
    "shell": [r"^\s*(?:sudo|git|npm|pip|cd|ls|docker|curl)\s", r"^\s*\$ "],
}
GENERIC_CODE = [r"[{};]\s*$", r"\)\s*\{", r"==|!=|&&|\|\|", r"^\s{2,}\S", r"\w+\(.*\)", r"^\s*(?://|#|/\*)"]


def to_hex(text):
    """Return a Tk-compatible #rrggbb string for a color clip, else None."""
    t = text.strip()
    if HEX_RE.match(t):
        return t[:7] if len(t) == 9 else t
    m = RGB_RE.match(t)
    if m:
        r, g, b = (min(int(x), 255) for x in m.groups())
        return f"#{r:02x}{g:02x}{b:02x}"
    return None


def classify(text):
    """Return (kind, language) for a clipboard string."""
    t = text.strip()
    single = "\n" not in t
    if single and to_hex(t):
        return "color", ""
    if single and URL_RE.match(t):
        return "url", ""
    if single and EMAIL_RE.match(t):
        return "email", ""
    if single and PATH_RE.match(t):
        return "path", ""
    if t[:1] in "{[":
        try:
            json.loads(t)
            return "json", ""
        except ValueError:
            pass
    scores = {lang: sum(bool(re.search(p, t, re.M | re.I)) for p in pats)
              for lang, pats in LANG_HINTS.items()}
    best = max(scores, key=scores.get)
    generic = sum(bool(re.search(p, t, re.M)) for p in GENERIC_CODE)
    if scores[best] >= 2 or (scores[best] >= 1 and generic >= 1) or generic >= 3:
        return "code", best if scores[best] else ""
    return "text", ""


# ---------------------------------------------------------------- storage
class Store:
    def __init__(self, path=DB_PATH):
        self.db = sqlite3.connect(path)
        self.db.execute(
            """CREATE TABLE IF NOT EXISTS clips(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                content TEXT UNIQUE NOT NULL,
                kind TEXT NOT NULL,
                lang TEXT DEFAULT '',
                pinned INTEGER DEFAULT 0,
                ts REAL NOT NULL)"""
        )
        self.db.commit()

    def add(self, content):
        kind, lang = classify(content)
        cur = self.db.execute("UPDATE clips SET ts=? WHERE content=?", (time.time(), content))
        if cur.rowcount == 0:
            self.db.execute("INSERT INTO clips(content,kind,lang,ts) VALUES(?,?,?,?)",
                            (content, kind, lang, time.time()))
        self.db.commit()

    def query(self, kind="all", search=""):
        sql, args = "SELECT id,content,kind,lang,pinned,ts FROM clips WHERE 1=1", []
        if kind != "all":
            sql += " AND kind=?"
            args.append(kind)
        if search:
            sql += " AND content LIKE ?"
            args.append(f"%{search}%")
        sql += " ORDER BY pinned DESC, ts DESC LIMIT 500"
        return self.db.execute(sql, args).fetchall()

    def get(self, cid):
        return self.db.execute("SELECT id,content,kind,lang,pinned,ts FROM clips WHERE id=?", (cid,)).fetchone()

    def toggle_pin(self, cid):
        self.db.execute("UPDATE clips SET pinned = 1 - pinned WHERE id=?", (cid,))
        self.db.commit()

    def delete(self, cid):
        self.db.execute("DELETE FROM clips WHERE id=?", (cid,))
        self.db.commit()

    def clear_unpinned(self):
        self.db.execute("DELETE FROM clips WHERE pinned=0")
        self.db.commit()


# ---------------------------------------------------------------- UI
KINDS = ["all", "color", "code", "url", "json", "path", "email", "text"]
ICONS = {"color": "🎨", "code": "💻", "url": "🔗", "json": "{ }", "path": "📁", "email": "✉", "text": "📝"}


class CodeClip:
    def __init__(self, root):
        self.root = root
        self.store = Store()
        self.last = None
        root.title("CodeClip")
        root.geometry("820x520")
        root.minsize(640, 400)

        # top bar: search + filter
        top = ttk.Frame(root, padding=8)
        top.pack(fill="x")
        self.search = tk.StringVar()
        self.search.trace_add("write", lambda *_: self.refresh())
        ttk.Label(top, text="Search").pack(side="left")
        ttk.Entry(top, textvariable=self.search).pack(side="left", fill="x", expand=True, padx=6)
        self.kind = tk.StringVar(value="all")
        box = ttk.Combobox(top, textvariable=self.kind, values=KINDS, state="readonly", width=8)
        box.pack(side="left")
        box.bind("<<ComboboxSelected>>", lambda _e: self.refresh())

        # main split: list + detail
        pane = ttk.PanedWindow(root, orient="horizontal")
        pane.pack(fill="both", expand=True, padx=8)

        left = ttk.Frame(pane)
        cols = ("type", "preview", "time")
        self.tree = ttk.Treeview(left, columns=cols, show="headings", selectmode="browse")
        for c, w in zip(cols, (90, 320, 70)):
            self.tree.heading(c, text=c.title())
            self.tree.column(c, width=w, anchor="w", stretch=(c == "preview"))
        sb = ttk.Scrollbar(left, command=self.tree.yview)
        self.tree.configure(yscrollcommand=sb.set)
        self.tree.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")
        pane.add(left, weight=3)

        right = ttk.Frame(pane, padding=(8, 0, 0, 0))
        self.meta = ttk.Label(right, text="Select a clip", font=("TkDefaultFont", 10, "bold"))
        self.meta.pack(anchor="w")
        self.swatch = tk.Label(right, height=3, relief="solid", bd=1)
        self.detail = tk.Text(right, wrap="word", height=10, font=("Courier", 10), state="disabled")
        self.detail.pack(fill="both", expand=True, pady=(6, 0))
        pane.add(right, weight=2)

        # bottom buttons
        bar = ttk.Frame(root, padding=8)
        bar.pack(fill="x")
        ttk.Button(bar, text="Copy (Enter)", command=self.copy_selected).pack(side="left")
        ttk.Button(bar, text="Pin / Unpin", command=self.pin_selected).pack(side="left", padx=6)
        ttk.Button(bar, text="Delete (Del)", command=self.delete_selected).pack(side="left")
        ttk.Button(bar, text="Clear unpinned", command=self.clear).pack(side="right")
        self.status = ttk.Label(bar, text="Watching clipboard…")
        self.status.pack(side="right", padx=12)

        self.tree.bind("<<TreeviewSelect>>", self.on_select)
        self.tree.bind("<Double-1>", lambda _e: self.copy_selected())
        root.bind("<Return>", lambda _e: self.copy_selected())
        self.tree.bind("<Delete>", lambda _e: self.delete_selected())

        self.refresh()
        self.poll()

    # -- clipboard watcher
    def poll(self):
        try:
            text = self.root.clipboard_get()
        except tk.TclError:  # empty or non-text clipboard
            text = None
        if text and text != self.last and text.strip() and len(text) <= MAX_LEN:
            self.last = text
            self.store.add(text)
            self.refresh()
            kind, _ = classify(text)
            self.status.config(text=f"Captured {kind}")
        self.root.after(POLL_MS, self.poll)

    # -- list handling
    def refresh(self):
        sel = self.tree.selection()
        self.tree.delete(*self.tree.get_children())
        for cid, content, kind, lang, pinned, ts in self.store.query(self.kind.get(), self.search.get()):
            label = f"{'📌 ' if pinned else ''}{ICONS.get(kind, '')} {kind}"
            preview = " ".join(content.split())[:90]
            self.tree.insert("", "end", iid=str(cid),
                             values=(label, preview, time.strftime("%H:%M", time.localtime(ts))))
        if sel and self.tree.exists(sel[0]):
            self.tree.selection_set(sel[0])

    def selected_id(self):
        sel = self.tree.selection()
        return int(sel[0]) if sel else None

    def on_select(self, _e=None):
        cid = self.selected_id()
        row = self.store.get(cid) if cid else None
        if not row:
            return
        _, content, kind, lang, pinned, _ts = row
        self.meta.config(text=f"{kind}{' · ' + lang if lang else ''} · {len(content)} chars")
        hexcol = to_hex(content) if kind == "color" else None
        if hexcol:
            self.swatch.config(bg=hexcol)
            self.swatch.pack(fill="x", before=self.detail)
        else:
            self.swatch.pack_forget()
        self.detail.config(state="normal")
        self.detail.delete("1.0", "end")
        self.detail.insert("1.0", content)
        self.detail.config(state="disabled")

    # -- actions
    def copy_selected(self):
        cid = self.selected_id()
        row = self.store.get(cid) if cid else None
        if not row:
            return
        self.last = row[1]  # avoid re-capturing our own copy as a "new" item
        self.root.clipboard_clear()
        self.root.clipboard_append(row[1])
        self.store.add(row[1])  # bump to top
        self.status.config(text="Copied to clipboard")
        self.refresh()

    def pin_selected(self):
        cid = self.selected_id()
        if cid:
            self.store.toggle_pin(cid)
            self.refresh()

    def delete_selected(self):
        cid = self.selected_id()
        if cid:
            self.store.delete(cid)
            self.refresh()

    def clear(self):
        self.store.clear_unpinned()
        self.refresh()


if __name__ == "__main__":
    root = tk.Tk()
    CodeClip(root)
    root.mainloop()
